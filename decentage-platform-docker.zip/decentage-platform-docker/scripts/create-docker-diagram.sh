#!/bin/bash -e
ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd -P);
echo ROOT_DIR=${ROOT_DIR}
rm -f ${ROOT_DIR}/.env
ln -v ${ROOT_DIR}/hosts/dop-test.decentage.io/.env ${ROOT_DIR}/.env
cd ${ROOT_DIR}
docker run --rm -it --name dcv -v ${ROOT_DIR}:/input pmsipilot/docker-compose-viz render -m image --force --output-file=docs/store-assets/DECENTAGE-dop-docker-diagram.png docker-compose.yml