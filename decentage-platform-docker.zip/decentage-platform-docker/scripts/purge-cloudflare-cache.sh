#!/bin/bash

function purge_cloudflare_cache() {
	zone_id=$1
    purge_url="https://${2}"
    api_token=$3
    echo "Purging cloudflare cache for zone ${zone_id} and url ${purge_url}"
	curl -X POST "https://api.cloudflare.com/client/v4/zones/${zone_id}/purge_cache" -H "Authorization: Bearer ${api_token}" -H "Content-Type: application/json" --data '{"files":["'"${purge_url}"'"]}'
}

