#!/bin/bash -e
# docker system prune --all --force
# docker volume prune --force

docker-compose -f docker-compose.yml rm -f
