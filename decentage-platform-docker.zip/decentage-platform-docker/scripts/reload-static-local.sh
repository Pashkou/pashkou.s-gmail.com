#!/bin/bash -e

docker-compose -f ../docker-compose.localhost.yml up --build --force-recreate static-file-server