#!/bin/bash
export ROOT_DIR=.
echo ROOT_DIR=${ROOT_DIR}
function log_message { 
	echo "$@" >&2; 
}
function die { 
	warn "$@"; exit 1; 
}

function calc_release_version {
	version="$1"
	release_type="$2"
	release_offset="$3"
	major=0
	minor=0
	build=0
	
	# break down the version number into it's components
	regex="([0-9]+).([0-9]+).([0-9]+)"
	if [[ $version =~ $regex ]]; then
	  major="${BASH_REMATCH[1]}"
	  minor="${BASH_REMATCH[2]}"
	  build="${BASH_REMATCH[3]}"
	fi
	
	# check paramater to see which number to increment
	if [[ "$release_type" == "feature" ]]; then
	  minor=$(echo $minor ${release_offset} | bc)
	elif [[ "$release_type" == "bug" ]]; then
	  build=$(echo $build ${release_offset} | bc)
	elif [[ "$release_type" == "major" ]]; then
	  major=$(echo $major ${release_offset} | bc)
	else
	  echo "usage: calc_release_version version_number [major/feature/bug]"
	  exit -1
	fi
	
	# echo the new version number
	echo "${major}.${minor}.${build}"
}

function update_release_version_hosts {
	version="$1"
	release_type="$2"
	new_version=$(calc_release_version ${version} ${release_type} "+1")
	log_message "Updating release version from ${version} to ${new_version} in ${ROOT_DIR}/hosts (${release_type})"
	find ${ROOT_DIR}/hosts -type f -name ".env" -print0 | xargs -0 sed -i "/DECENTAGE_DOP_RELEASE_VERSION=/ s/=.*/=${new_version}/"
	echo "${new_version}"
}


function update_release_version {
	version="$1"
	release_type="$2"
	new_version=$(calc_release_version ${version} ${release_type} "+1")
	log_message "Updating release version from ${version} to ${new_version} in ${ROOT_DIR}/release.properties (${release_type})"
	echo "version=${new_version}" > ${ROOT_DIR}/release.properties
	echo "${new_version}"
}
