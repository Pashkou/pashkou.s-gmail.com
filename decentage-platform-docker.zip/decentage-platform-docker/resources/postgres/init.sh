#!/bin/bash
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
	CREATE USER dop_camunda WITH PASSWORD 'dop_camunda';
	CREATE DATABASE dop_camunda;
	GRANT ALL PRIVILEGES ON DATABASE dop_camunda TO dop_camunda;
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
	CREATE USER dop_documents WITH PASSWORD 'dop_documents';
	CREATE DATABASE dop_documents;
	GRANT ALL PRIVILEGES ON DATABASE dop_documents TO dop_documents;
EOSQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
	CREATE USER dop_keycloak WITH PASSWORD 'dop_keycloak';
	CREATE DATABASE dop_keycloak;
	GRANT ALL PRIVILEGES ON DATABASE dop_keycloak TO dop_keycloak;
EOSQL