const SET_USER = 'SET_USER';

export const setUser = (user) => ({
    type: SET_USER,
    payload: user
});

export default (previousState = null, { type, payload }) => {
    if (type === SET_USER) {
        return payload;
    }
    return previousState;
};
