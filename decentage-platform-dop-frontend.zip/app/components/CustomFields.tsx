import React from "react";
import {Chip} from "@material-ui/core";

// FIELDS

export const FullNameField = ( props ) => <span>{props.record.firstName} {props.record.lastName}</span>;

export const IconField = ( props ) => props.icons[props.record[props.source]];

export const TwoLineField = ( props ) => {
    const {record, line1, line2} = props;

    return (
        <div>
        <span>{record[line1]}</span><br/>
        <span style={{opacity: 0.5}}>{record[line2]}</span>
        </div>
    )
}
