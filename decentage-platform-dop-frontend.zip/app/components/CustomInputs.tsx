import React from "react";
import {
    KeyboardDatePicker, MuiPickersUtilsProvider,
} from '@material-ui/pickers';
import DateFnsUtils from "@date-io/moment";
import {useInput} from 'react-admin';

// INPUTS

export const DatePickerInput = ( props ) => {
    const {
        input: { onChange, value }
    } = useInput(props);

    return (
        <MuiPickersUtilsProvider utils={DateFnsUtils}><KeyboardDatePicker
            margin="normal"
            id="date-picker-dialog"
            label={props.source}
            format="YYYY-MM-DD"
            value={value}
            onChange={onChange}
            KeyboardButtonProps={{
                'aria-label': 'change date',
            }}
        /></MuiPickersUtilsProvider>);
}
