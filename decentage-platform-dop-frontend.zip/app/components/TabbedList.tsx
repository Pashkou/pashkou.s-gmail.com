import React, {Fragment} from "react";
import {createStyles, Paper, Tab, Tabs, Theme, withStyles} from "@material-ui/core";
import {List} from "react-admin";

const styles = (theme: Theme) =>
    createStyles({
        root: {
            paddingBottom: 40
        },
    });

const TabbedList = props => {
    const {classes, tabs} = props;
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const a11yProps = (index) => {
        return {
            id: `tab-${index}`,
            'aria-controls': `tabpanel-${index}`,
        };
    }

    return (
        <Fragment>
            <Paper className={classes.root}>
                <Tabs
                    value={value}
                    indicatorColor="primary"
                    textColor="primary"
                    onChange={handleChange}
                    aria-label="disabled tabs example"
                >
                    {tabs.map((item, index) => {
                        return (
                            <Tab label={item.label} key={index} {...a11yProps(index)} />
                        )

                    })}
                </Tabs>
                {tabs.map((item, index) => {
                    if (value === index) {
                        return (
                            <List
                                component="div"
                                role="tabpanel"
                                hidden={value !== index}
                                id={`tabpanel-${index}`}
                                aria-labelledby={`tab-${index}`}
                                filter={item.filter}
                                key={index}
                                {...props}
                            />
                        )
                    }
                    return null;
                })}
            </Paper>
        </Fragment>
    )
}

export default  withStyles(styles)(TabbedList);
