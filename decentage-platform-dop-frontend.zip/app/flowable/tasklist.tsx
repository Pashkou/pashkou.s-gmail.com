import React, {useEffect} from 'react';

import { ProcessInstancesApi} from './process';

import axios from "axios";


const Tasklist = (props) => {

    useEffect(() => {

        const api = new ProcessInstancesApi();
        api.getProcessInstance("")


        axios("http://localhost:9060/flowable-rest/service/runtime/process-instances", {method: "GET"}).then((result) => {
            console.log(result);
        })
    })

    return (
        <ul>

        </ul>
    )
}


export default Tasklist;
