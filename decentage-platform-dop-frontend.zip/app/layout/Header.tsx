import React, {forwardRef} from 'react';
import AppBar from '@material-ui/core/AppBar';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import HelpIcon from '@material-ui/icons/Help';
import Hidden from '@material-ui/core/Hidden';
import IconButton from '@material-ui/core/IconButton';
import Link from '@material-ui/core/Link';
import MenuIcon from '@material-ui/icons/Menu';
import NotificationsIcon from '@material-ui/icons/Notifications';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import Toolbar from '@material-ui/core/Toolbar';
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';
import { createStyles, Theme, withStyles, WithStyles } from '@material-ui/core/styles';
import {MenuItemLink, useTranslate, useLogout, useLogin, useAuthState, useSetLocale, useLocale} from "react-admin";
import SettingsIcon from "@material-ui/core/SvgIcon/SvgIcon";
import {Card, CardContent, Chip} from "@material-ui/core";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import {useStore} from "react-redux";
import {Flag} from "@material-ui/icons";

const styles = (theme: Theme) =>
  createStyles({
    appBar: {
        padding:27
    },
    secondaryBar: {
      zIndex: 0,
    },
    menuButton: {
      marginLeft: -theme.spacing(1),
      color: theme.palette.secondary.contrastText,
      fontSize: "20px"
    },
    MuiIconButton: {
        color: theme.palette.secondary.contrastText
    },
    link: {
      textDecoration: 'none',
      color: theme.palette.secondary.contrastText,
      '&:hover': {
        color: theme.palette.secondary.contrastText,
      },
    },
    button: {
      borderColor: theme.palette.secondary.contrastText
    },
  });

interface HeaderProps extends WithStyles<typeof styles> {
  onDrawerToggle: () => void;
}

const LoginButton = forwardRef((props: any, ref: any) => {
    const { loading, authenticated } = useAuthState();
    const logout = useLogout();
    const login = useLogin();

    if (!loading) {
        let handleClick;
        let label;
        if (authenticated) {
            handleClick = () => logout();
            label = "Logout";
        } else {
            handleClick = () => login();
            label = "Login";
        }

        return (
            <MenuItem
                onClick={handleClick}
                ref={ref}
            >
                {label}
            </MenuItem>
        );
    }

    return null;

});

const UserMenu = (props: any) => {
    const [anchorEl, setAnchorEl] = React.useState(null);

    const handleClick = (event: any) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div>
            <div aria-controls="user-menu" aria-haspopup="true" onClick={handleClick}>

                {props.button}
            </div>
            <Menu
                id="user-menu"
                anchorEl={anchorEl}
                keepMounted
                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <MenuItem onClick={handleClose}>Profile</MenuItem>
                <MenuItem onClick={handleClose}>My account</MenuItem>
                <LoginButton {...props} />
            </Menu>
        </div>
    );
}

const LanguageMenu = (props:any) => {
    const {classes} = props;
    const [anchorEl, setAnchorEl] = React.useState(null);
    const setLocale = useSetLocale();
    const locale = useLocale();
    const translate = useTranslate();

    const handleClick = (event: any) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return (
        <div>
            <Tooltip title="Select">
            <IconButton className={classes.menuButton} aria-controls="language-menu" aria-haspopup="true" onClick={handleClick}>
                <i className="fas fa-globe-africa"></i>
            </IconButton>
            </Tooltip>
        <Menu
            id="language-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
        >
            <MenuItem onClick={() => {setLocale("en"); handleClose()}}>{translate("en")}</MenuItem>
            <MenuItem onClick={() => {setLocale("de"); handleClose()}}>{translate("de")}</MenuItem>
            <MenuItem onClick={() => {setLocale("fr"); handleClose()}}>{translate("fr")}</MenuItem>
        </Menu>
        </div>
    )
}

const Header = (props: HeaderProps) => {
  const { classes, onDrawerToggle } = props;
  const { user } = useStore().getState();

  return (
    <React.Fragment>
      <AppBar className={classes.appBar} color="secondary" position="static" elevation={0}>
        <Toolbar>
          <Grid container spacing={1} alignItems="center">
            <Hidden smUp>
              <Grid item>
                <IconButton
                  color="inherit"
                  aria-label="open drawer"
                  onClick={onDrawerToggle}
                  className={classes.menuButton}
                >
                  <MenuIcon />
                </IconButton>
              </Grid>
            </Hidden>
            <Grid item xs />
              <Grid item>
                  <LanguageMenu {...props} />
              </Grid>
            <Grid item>
              <Tooltip title="Alerts • No alerts">
                <IconButton className={classes.menuButton}>
                  <NotificationsIcon />
                </IconButton>
              </Tooltip>
            </Grid>
            <Grid item>
                {user ?
                    <UserMenu {...props} button={
                        <Tooltip title="Account">
                            <IconButton className={classes.menuButton}>
                                <AccountCircleIcon/> {user.firstName + " " + user.lastName}
                            </IconButton>
                        </Tooltip>
                    }/>
                    :
                    <UserMenu {...props} button={
                        <Tooltip title="Account">
                            <IconButton className={classes.menuButton}>
                                <AccountCircleIcon/>
                            </IconButton>
                        </Tooltip>
                    }/>
                }
            </Grid>
          </Grid>
        </Toolbar>
      </AppBar>
    </React.Fragment>
  );
}

export default withStyles(styles)(Header);
