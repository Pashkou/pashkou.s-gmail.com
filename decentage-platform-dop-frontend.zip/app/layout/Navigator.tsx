import React, {useEffect} from 'react';
import clsx from 'clsx';
import {createStyles, fade, darken, Theme, withStyles, WithStyles} from '@material-ui/core/styles';
import { Omit } from '@material-ui/types';
import {MenuItemLink, useTranslate, useSetLocale} from "react-admin";
import Logo from './Logo';
import { withRouter } from 'react-router-dom';
import {Button, ExpansionPanel as MuiExpansionPanel, ExpansionPanelDetails as MuiExpansionPanelDetails, ExpansionPanelSummary as MuiExpansionPanelSummary, Drawer, DrawerProps, MenuList, List, ListItem, ListItemText, Divider} from "@material-ui/core";
import {useDispatch, useSelector} from "react-redux";
import {setTheme, setToken} from "app/reducers/siteReducer";
import adminNav from "app/themes/adminNav";
import clientNav from "app/themes/clientNav";

const styles = (theme: Theme) =>
  createStyles({
    categoryHeader: {
      paddingTop: theme.spacing(2),
      paddingBottom: theme.spacing(2),
    },
    categoryHeaderPrimary: {
      color: theme.palette.secondary.contrastText,
    },
    item: {
      paddingTop: theme.spacing(1),
      paddingBottom: theme.spacing(1),
        color: theme.palette.secondary.contrastText,
      '&:hover,&:focus': {
        backgroundColor: fade(theme.palette.primary.main, 0.1),
      },
    },
    itemCategory: {
      backgroundColor: theme.palette.secondary.dark,
      boxShadow: `0 -1px 0 ${theme.palette.secondary.light} inset`,
      paddingTop: theme.spacing(2),
      paddingBottom: theme.spacing(2),
    },
    itemActiveItem: {
        backgroundColor: fade(theme.palette.primary.main, 0.1),
        color: theme.palette.primary.dark
    },
    itemPrimary: {
      fontSize: 'inherit',
    },
    itemIcon: {
      minWidth: 'auto',
      marginRight: theme.spacing(2),
    },
    divider: {
      backgroundColor: theme.palette.secondary.light,
    },
  });


const ExpansionPanel = withStyles(theme => ({
    root: {
        border: 0,
        boxShadow: 'none',
        color: theme.palette.secondary.contrastText,
        /*
        '&:not(:last-child)': {
            borderBottom: 0,
        },
        '&:before': {
            display: 'none',
        },*/
        '&$expanded': {
            margin: 'auto',
        },
        '&:before': {
            background: theme.palette.secondary.light,
        }
    },
    expanded: {},
}))(MuiExpansionPanel);

const ExpansionPanelSummary = withStyles(theme => ({
    root: {
        backgroundColor: theme.palette.secondary.dark,
        borderBottom: `1px solid ${theme.palette.secondary.light}`,
        minHeight: 56,
        '&$expanded': {
            minHeight: 56,
        },
        '& i': {
            color: theme.palette.secondary.contrastText,
            fontSize: 12
        }
    },
    content: {
        '&$expanded': {
            margin: '12px 0',
        },
    },
    expanded: {},
}))(MuiExpansionPanelSummary);

const ExpansionPanelDetails = withStyles(theme => ({
    root: {
        backgroundColor: theme.palette.secondary.light,
        padding: "1em 0",
        borderBottom: `1px solid ${theme.palette.secondary.light}`,
    },
}))(MuiExpansionPanelDetails);



export interface NavigatorProps extends Omit<DrawerProps, 'classes'>, WithStyles<typeof styles> {}

const Navigator = withRouter((props: any) => {
    const { classes, onMenuClick, dense, logout, location, staticContext, ...other } = props;
    const siteState = useSelector((state: any) => state.site);
    const dispatch = useDispatch();
    const translate = useTranslate();

    let categories;

    if (siteState.theme === "admin") {
        categories = adminNav;
    } else if (siteState.theme === "client") {
        categories = clientNav;
    }


    const handleChange = (panel: number) => (event: React.ChangeEvent<{}>, newExpanded: boolean) => {
        let token = null;

        for (let key in siteState.tokenList) {
            let tokenItem = siteState.tokenList[key];
            if (tokenItem.id === panel) {
                token = tokenItem;
                break;
            }
        }

        dispatch(setToken(token));
    };
    const setLocale = useSetLocale();

  return (
    <Drawer variant="permanent" {...other}>
      <List disablePadding>
        <ListItem className={clsx(classes.firebase, classes.item, classes.itemCategory)}>
          <Logo />
        </ListItem>

        {categories.map(({ text, children }, i) => (
          <React.Fragment key={i}>
            <ListItem className={classes.categoryHeader}>
              <ListItemText
                classes={{
                  primary: classes.categoryHeaderPrimary,
                }}
              >
                {translate(text)}
              </ListItemText>
            </ListItem>

              <MenuItemLink
                  to={"/"}
                  primaryText={"Change theme"}
                  onClick={()=> {dispatch(setTheme(siteState.theme === "admin" ? "client" : "admin"))}}
              />

            {children.map(({ text, icon, to }, i) => {
                let clses;

                if (location.pathname.indexOf(to) >= 0) {
                    clses = clsx(classes.item, classes.itemPrimary, classes.itemActiveItem);
                } else {
                    clses = clsx(classes.item, classes.itemPrimary);
                }

                return (
                    <MenuItemLink
                        key={i}
                        to={to}
                        primaryText={translate(text, {
                            smart_count: 2,
                        })}
                        leftIcon={icon}
                        onClick={onMenuClick}
                        dense={dense}
                        className={clses}
                    />
                )
            })}
              <Divider className={classes.divider} />


              {siteState.tokenList && siteState.tokenList.map((value, index) => {

                  return (
                      <ExpansionPanel key={index} square expanded={siteState.token && siteState.token.id === value.id} onChange={handleChange(value.id)}>
                          <ExpansionPanelSummary
                              expandIcon={<i className="fa fa-chevron-down" />}
                              aria-controls={"panel" + value.id + "-content"}
                              id={"panel" + value.id + "-header"}
                          >
                              {value.name}
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails>
                              <MenuList>
                                  {children.map(({ text, icon, to }, i) => {
                                      let clses;

                                      if (location.pathname.indexOf(to) >= 0) {
                                          clses = clsx(classes.item, classes.itemPrimary, classes.itemActiveItem);
                                      } else {
                                          clses = clsx(classes.item, classes.itemPrimary);
                                      }

                                      return (
                                          <MenuItemLink
                                              key={i}
                                              to={to}
                                              primaryText={translate(text, {
                                                  smart_count: 2,
                                              })}
                                              leftIcon={icon}
                                              onClick={onMenuClick}
                                              dense={dense}
                                              className={clses}
                                          />
                                      )
                                  })}
                              </MenuList>
                          </ExpansionPanelDetails>
                      </ExpansionPanel>
                  )
              })}

          </React.Fragment>
        ))}
      </List>
    </Drawer>
  );
})


export default withStyles(styles)(Navigator);
