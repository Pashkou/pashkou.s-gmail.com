import TextTranslationsList from './TextTranslationsList';

export default {
    list: TextTranslationsList
};
