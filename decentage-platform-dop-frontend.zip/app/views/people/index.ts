import PeopleList from './PeopleList';
import PeopleEdit from "./PeopleEdit";
import PeopleCreate from "./PeopleCreate";

export default {
    list: PeopleList,
    edit: PeopleEdit,
    create: PeopleCreate
};
