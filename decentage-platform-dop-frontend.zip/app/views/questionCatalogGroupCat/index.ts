import QuestionCatalogGroupCatList from './QuestionCatalogGroupCatList';
import {QuestionCatalogGroupCatEdit} from "./QuestionCatalogGroupCatEdit";

export default {
    list: QuestionCatalogGroupCatList,
    edit: QuestionCatalogGroupCatEdit
};
