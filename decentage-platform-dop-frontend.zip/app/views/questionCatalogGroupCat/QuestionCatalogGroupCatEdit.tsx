import React from 'react';
import {Edit, SimpleForm, TextInput, ReferenceInput, SelectInput} from "react-admin";

export const QuestionCatalogGroupCatEdit = props => (
    <Edit {...props}>
        <SimpleForm>
            <TextInput source="id" />
            <ReferenceInput source="helpId" reference="text-translations"><SelectInput optionText="key" /></ReferenceInput>
            <ReferenceInput source="helpTextId" reference="text-translations"><SelectInput optionText="key" /></ReferenceInput>
        </SimpleForm>
    </Edit>
);
