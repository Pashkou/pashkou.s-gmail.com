import { stringify } from 'query-string';
import { fetchUtils, DataProvider } from 'ra-core';

/**
 * Maps react-admin queries to a json-server powered REST API
 *
 * @see https://github.com/typicode/json-server
 *
 * @example
 *
 * getList          => GET http://my.api.url/posts?_sort=title&_order=ASC&_start=0&_end=24
 * getOne           => GET http://my.api.url/posts/123
 * getManyReference => GET http://my.api.url/posts?author_id=345
 * getMany          => GET http://my.api.url/posts/123, GET http://my.api.url/posts/456, GET http://my.api.url/posts/789
 * create           => POST http://my.api.url/posts/123
 * update           => PUT http://my.api.url/posts/123
 * updateMany       => PUT http://my.api.url/posts/123, PUT http://my.api.url/posts/456, PUT http://my.api.url/posts/789
 * delete           => DELETE http://my.api.url/posts/123
 *
 * @example
 *
 * import React from 'react';
 * import { Admin, Resource } from 'react-admin';
 * import jsonServerProvider from 'ra-data-json-server';
 *
 * import { PostList } from './posts';
 *
 * const App = () => (
 *     <Admin dataProvider={jsonServerProvider('http://jsonplaceholder.typicode.com')}>
 *         <Resource name="posts" list={PostList} />
 *     </Admin>
 * );
 *
 * export default App;
 */
export default (apiUrl, httpClient): DataProvider => ({
    getList: (resource, params) => {
        const { page, perPage } = params.pagination;
        const { field, order } = params.sort;
        let filter = {}
        let key: any, value: any;
        for ([key, value] of Object.entries(params.filter)) {
            if (typeof value === "string" && value.indexOf(",") >= 0) {
                filter[key + ".in"] = value;
            } else {
                filter[key + ".equals"] = value;
            }
        }
        const query = {
            ...filter
        }
        if (page) query['page'] = page - 1;
        if (perPage) query['size'] = perPage;
        if (field) query['sort'] = field + "," + order.toLowerCase();

        const url = `${apiUrl}/${resource}?${stringify(query)}`;

        return httpClient(url).then(({ headers, json }) => {
            if (!headers.has('x-total-count')) {
                throw new Error(
                    'The X-Total-Count header is missing in the HTTP Response. The jsonServer Data Provider expects responses for lists of resources to contain this header with the total number of results to build the pagination. If you are using CORS, did you declare X-Total-Count in the Access-Control-Expose-Headers header?'
                );
            }
            return {
                data: json,
                total: parseInt(
                    headers
                        .get('x-total-count')
                        .split('/')
                        .pop(),
                    10
                ),
            };
        });
    },

    getOne: (resource, params) => {
        return httpClient(`${apiUrl}/${resource}/${params.id}`).then(({ json }) => ({
            data: json,
        }))
    },

    getMany: (resource, params) => {
        const query = {
            filter: JSON.stringify({ id: params.ids })
        };
        let idStr = "";
        params.ids.map(id => idStr + `id=${id}`);
        const url = `${apiUrl}/${resource}?${idStr}`;
        return httpClient(url).then(({ json }) => ({ data: json }));
    },

    getManyReference: (resource, params) => {
        const { page, perPage } = params.pagination;

        // Create query with pagination params.
        const query = {
            'page[number]': page,
            'page[size]': perPage,
        };

        // Add all filter params to query.
        Object.keys(params.filter || {}).forEach((key) => {
            query[`filter[${key}]`] = params.filter[key];
        });

        // Add the reference id to the filter params.
        query[`filter[${params.target}]`] = params.id;

        let url = `${apiUrl}/${resource}?${stringify(query)}`;

        return httpClient(url).then((response) => ({
            data: response.json.map(value => Object.assign(
                { id: value.id },
                value.attributes,
            )),
            total: response.json.length,
        }));
    },

    update: ((resource, params) => {
        console.log("Update Called")
        console.log(params)
        return httpClient(`${apiUrl}/${resource}`, {
            method: 'PUT',
            data: JSON.stringify(params.data),
        }).then(({json}) => ({data: json}))
    }),

    // json-server doesn't handle filters on UPDATE route, so we fallback to calling UPDATE n times instead
    updateMany: ((resource, params) => {
        console.log("UpdateMany Called")

        return Promise.all(
            params.ids.map(id =>
                httpClient(`${apiUrl}/${resource}/${id}`, {
                    method: 'PUT',
                    data: JSON.stringify(params.data),
                })
            )
        ).then(responses => ({data: responses.map(({json}) => json.id)}))
    }),
    create: ((resource, params) => {
        console.log("Create Called", params)

        return httpClient(`${apiUrl}/${resource}`, {
            method: 'POST',
            data: params.data// JSON.stringify(params.data),
        }).then(({json}) => ({
            data: {...params.data, id: json.id},
        }))
    }),
    delete: ((resource, params) => {
        console.log("Delete Called")
        return httpClient(`${apiUrl}/${resource}/${params.id}`, {
            method: 'DELETE',
        }).then(({json}) => ({data: json}))

        // json-server doesn't handle filters on DELETE route, so we fallback to calling DELETE n times instead
    }),
    deleteMany: ((resource, params) => {
        console.log("DeleteMany Called");
        console.log(params);
        return Promise.all(
            params.ids.map(id =>
                httpClient(`${apiUrl}/${resource}/${id}`, {
                    method: 'DELETE',
                })
            )
        ).then(responses => ({
            data: responses.map(response => response.json)
        }));
    })
});
