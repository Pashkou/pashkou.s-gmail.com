const assert = require('assert');
const request = require('request');
const util = require('util')

//get host from config
const { host } = browser.config.testCaseEnv;
const { services } = browser.config;
const isCrossbrowsertesting = services.includes('crossbrowsertesting');
let userId = makeid(5);
const emailPattern = `mytestemail_${userId}@seba.com`;
const firstNamePattern = `testuser_${userId}_first`;
const lastNamePattern = `testuser_${userId}_last`;

const DISPLAY_TIMEOT = 30000;
const FIX_ID = '\\3';

function pauseOnEnd() {
    // browser.pause(1000);
}

function waitForAnimationEnd() {
    browser.pause(300);
}

const actions = new Actions();

describe('camunda process test', () => {
    // runs before all tests in this file
    before(() => {
        //open site
        browser.url(host);
    });

    after(function () {
        // console.log('after this', logCompact(this.currentTest.parent.parent.suites));

        const suites = this.currentTest.parent.parent.suites;
        //get final result: passed ot not
        const isPassed = getFinalResult(suites);

        //send result to Crossbrowsertesting
        if (isCrossbrowsertesting) {
            if (isPassed) {
                setScore('pass');
            } else {
                setScore('fail');
            }
        }
    });

    it('Register user', () => {
        const title = browser.getTitle();
        assert.equal(title, 'Log in to SEBA DOP');

        actions.setInputValue('input#email', emailPattern);
        actions.setInputValue('input#firstName', firstNamePattern);
        actions.setInputValue('input#lastName', lastNamePattern);
        
        actions.setInputValue('input#password', 'SomePass1980!!');
        actions.setInputValue('input#password-confirm', 'SomePass1980!!');

        actions.nextStepClick('button=Continue');
    });

    it('General Terms', () => {
        actions.waitForHeader('h1=General Terms and Conditions');

        const chkb2 = $(`input#AgreeTandC`);
        assert.equal(chkb2.isExisting(), true);

        // hackedClick(chkb1);
        hackedClick(chkb2);

        const lbl2 = $(`label*=I explicitly consent to the`);
        assert.equal(lbl2.isExisting(), true);
        // lbl2.click();

        actions.nextStepClick('button=Continue');
    });

    it('Client choose', () => {
        actions.waitForHeader('h1=Get started with SEBA');

        const retail = $(`div=Retail client`);
        const retailBtn = retail.$('..').$(`button=Continue`);
        assert.equal(retail.isExisting(), true);
        assert.equal(retailBtn.isExisting(), true);

        const professional = $(`div=Professional client`);
        const professionalBtn = professional.$('..').$(`button=Continue`);
        assert.equal(professional.isExisting(), true);
        assert.equal(professionalBtn.isExisting(), true);

        const corporate = $(`div=Corporate/Institutional client`);
        const corporateBtn = corporate.$('..').$(`button*=Contact SEBA`);
        assert.equal(corporate.isExisting(), true);
        assert.equal(corporateBtn.isExisting(), true);

        pauseOnEnd();
        //choose Retail client type
        retailBtn.click();
    });

    it('Initial Retail Onboarding', () => {
        actions.waitForHeader('h1=Initial onboarding declaration');

        const chkb1 = $(`input#soleBeneficialOwner`);
        assert.equal(chkb1.isExisting(), true);
        hackedClick(chkb1);

        const chkb2 = $(`input#usPerson`);
        assert.equal(chkb2.isExisting(), true);
        hackedClick(chkb2);

        const chkb3 = $(`input#notBornInUs`);
        assert.equal(chkb3.isExisting(), true);
        hackedClick(chkb3);

        const chkb4 = $(`input#noGreencard`);
        assert.equal(chkb4.isExisting(), true);
        hackedClick(chkb4);

        const chkb5 = $(`input#notUsResident`);
        assert.equal(chkb5.isExisting(), true);
        hackedClick(chkb5);
        
        const chkb6 = $(`input#noUsTax`);
        assert.equal(chkb6.isExisting(), true);
        hackedClick(chkb6);

        actions.setInputValue('input#companyId', 'SEBAFF');

        actions.nextStepClick('button=Continue');
    });

    it('Domicile', () => {
        actions.waitForHeader('h1=Domicile / Residency');

        actions.nextStepClick('button=Continue');
    });

    it('Identification', () => {
        actions.waitForHeader('h1=Identification');

        actions.setSelectValue('select#gender', 'Male');
        actions.setInputValue('input#title', 'Mr');
        // actions.setInputValue('input#firstName', 'Donald');
        // actions.setInputValue('input#lastName', 'Trump');

        const dateOfBirth = $(`input#dateOfBirth`).$('..');
        assert.equal(dateOfBirth.isExisting(), true);
        dateOfBirth.click();
        waitForAnimationEnd();
        const root = $('#dateOfBirth_root');
        root.$('select.picker__select--year').selectByVisibleText('1980');
        waitForAnimationEnd();
        const dateOfBirthValue = root.$('div.picker__day=15');
        assert.equal(dateOfBirthValue.isDisplayed(), true);
        dateOfBirthValue.click();
        waitForAnimationEnd();

        actions.setSelectValue('select#country', 'Germany');
        actions.setSelectValue('select#nationality', 'Germany');

        actions.nextStepClick('button=Continue');
    });

    it('Phone and domicile address', () => {
        actions.waitForHeader('h1=Phone and domicile address');

        actions.setInputValue('input#Mobile', '+7123456789');
        actions.setInputValue('input#Street', 'Test street');
        actions.setInputValue('input#StreetNumber', '123');
        actions.setInputValue('input#ZipCode', '123123');
        actions.setInputValue('input#City', 'Test city');
        actions.setInputValue('input#AdditionalAddressLine', 'Test add address 21341');

        actions.nextStepClick('button=Continue');
    });

    it('Choose Identification Method', () => {
        actions.waitForHeader('h1=Choose identification method');

        const onPremisesBtn = $(`div=IN PERSON`).$('..').$('button=Select');
        assert.equal(onPremisesBtn.isExisting(), true);
        pauseOnEnd();
        onPremisesBtn.click();
    });

    it('Nationalities and Correspondence', () => {
        actions.waitForHeader('h1=Nationalities and correspondence address');
        
        actions.nextStepClick('button=Continue');
    });

    it('Tax relevant countries', () => {
        actions.waitForHeader('h1=Tax residence countries');

        actions.setCkbChecked('input#agree');
        actions.nextStepClick('button=Continue');
    });

    // it('KYC Questionnaire', () => {
    //     //screen1
    //     actions.waitForHeader('h1=Initial deposit');
    //     actions.setInputValue(`input#${FIX_ID}1`, '150000');
    //     actions.setCkbChecked(`input#${FIX_ID}7`);
    //     actions.setInputValue(`input#${FIX_ID}8`, 'name and country');
    //     actions.nextStepClick('button=Next');

    //     //screen2
    //     actions.waitForHeader('h1=Basic information');
    //     actions.setCkbChecked(`label[for="18"]`);
    //     actions.setCkbChecked(`label[for="20"]`);
    //     actions.nextStepClick('button=Next');

    //     //screen3
    //     actions.waitForHeader('h1=Source of income / professional background');        
    //     actions.setCkbChecked(`label[for="51"]`);
    //     actions.setInputValue(`input#${FIX_ID}25`, '150000');
    //     actions.nextStepClick('button=Next');

    //     //screen 4
    //     actions.waitForHeader('h1=Business industries');
    //     actions.setCkbChecked(`input#${FIX_ID}66`);
    //     actions.nextStepClick('button=Next');

    //     //screen 5
    //     actions.waitForHeader('h1=Financial background');
    //     actions.setCkbChecked(`label[for="86"]`);
    //     actions.setCkbChecked(`input#${FIX_ID}90`);
    //     actions.nextStepClick('button=Next');

    //     //screen 6
    //     actions.waitForHeader('h1=Experience with digital assets');
    //     actions.setCkbChecked(`input#${FIX_ID}133`);
    //     actions.setCkbChecked(`label[for="140"]`);
    //     actions.setCkbChecked(`label[for="149"]`);
    //     actions.setCkbChecked(`label[for="154"]`);        
    //     actions.nextStepClick('button=Next');
    // });

    // it('Submit Application', () => {
    //     actions.waitForHeader('h1=Submit Application');
        
    //     // actions.nextStepClick('button=Continue');
    // });

    it('on exit pause 1 sec', () => {
        browser.pause(2000);
    });
});


// describe('camunda process test 2', () => {
// });

function Actions() {
    this.waitForHeader = function (selector) {
        const heading = $(selector);
        heading.waitForDisplayed(DISPLAY_TIMEOT);
        assert.equal(heading.isExisting(), true);
    }

    this.setInputValue = function (selector, value) {
        const input = $(selector);
        assert.equal(input.isExisting(), true);
        input.setValue(value);
    }

    this.setCkbChecked = function (selector) {
        const chkb = $(selector);
        assert.equal(chkb.isExisting(), true);
        hackedClick(chkb);
    }

    this.setSelectValue = function (selector, value) {
        const country = $(selector).$('..');
        assert.equal(country.isExisting(), true);
        country.click();
        waitForAnimationEnd();
        const countryValue = country.$(`li*=${value}`);
        assert.equal(countryValue.isDisplayed(), true);
        countryValue.click();
        waitForAnimationEnd();
    }

    this.nextStepClick = function (selector) {
        const continueBtn = $(selector);
        assert.equal(continueBtn.isExisting(), true);

        pauseOnEnd();
        continueBtn.click();
    }
}

function hackedClick(element) {
    browser.execute((el) => { el.click(); }, element);
}

function makeid(length) {
    var result = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

function logCompact(obj) {
    return util.inspect(obj, { compact: true, depth: 1, colors: true })
}

function getFinalResult(suites) {
    for (let i = 0; i < suites.length; i++) {
        let suite = suites[i];
        for (let j = 0; j < suite.tests.length; j++) {
            let test = suite.tests[j];
            if (test.state !== 'passed') {
                return false;
            }
        }
    }
    return true;
}

//Helper to set the score
function setScore(score) {
    var result = { error: false, message: null };

    if (browser.sessionId) {
        request({
            method: 'PUT',
            uri: 'https://crossbrowsertesting.com/api/v3/selenium/' + browser.sessionId,
            body: { 'action': 'set_score', 'score': score },
            json: true
        },
            function (error, response, body) {
                if (error) {
                    result.error = true;
                    result.message = error;
                }
                else if (response.statusCode !== 200) {
                    result.error = true;
                    result.message = body;
                }
                else {
                    result.error = false;
                    result.message = 'success';
                }

            })
            .auth(process.env.CBT_USERNAME, process.env.CBT_AUTHKEY);
    }
    else {
        result.error = true;
        result.message = 'Session Id was not defined';
    }
}