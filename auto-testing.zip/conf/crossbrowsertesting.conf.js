exports.config = {
    //demo test
    // testCaseEnv: {
    //     host: 'https://dop-demo.decentage.io'
    // },
    // cbtTunnel: false, //set to true if a local connection is needed
    
    //local test
    testCaseEnv: {
        host: 'http://localhost'
    },
    cbtTunnel: true,

    //local test using ngrok
    // testCaseEnv: {
    //     host: 'http://32fc1566.ngrok.io'
    // },
    // cbtTunnel: false,    

    runner: 'local',

    hostname: 'hub.crossbrowsertesting.com',
    port: 80,

    services: ['crossbrowsertesting'],
    user: process.env.CBT_USERNAME,
    key: process.env.CBT_AUTHKEY,

    specs: [
        './test/specs/**/*.js'
    ],
    exclude: [
        // 'path/to/excluded/files'
    ],

    maxInstances: 1,

    capabilities: [
        // {
        //     maxInstances: 1,
        //     name: 'SEBA iPhone X Safari Test',
        //     'browserName': 'Safari',
        //     'deviceName': 'iPhone X Simulator',
        //     'platformVersion': '11.0',
        //     'platformName': 'iOS',
        //     'deviceOrientation': 'portrait',
        //     record_video: 'true'
        // },
        {
            maxInstances: 1,
            name: 'SEBA Windows 10 Chrome Test',
            platform: 'Windows 10',
            browserName: 'Chrome',
            version: '75x64',
            screenResolution: '1366x768',
            record_video: 'true'
        },
        // {
        //     maxInstances: 1,
        //     name: 'SEBA Windows 10 Firefox Test',
        //     platform: 'Windows 10',
        //     browserName: 'Firefox',
        //     version: '67x64',
        //     screenResolution: '1366x768',
        //     record_video: 'true'
        // },
        // {
        //     maxInstances: 1,
        //     name: 'SEBA Android Pixel 3 Chrome Test',
        //     browserName: 'Chrome',
        //     deviceName: 'Pixel 3',
        //     platformVersion: '9.0',
        //     platformName: 'Android',
        //     deviceOrientation: 'portrait',
        //     record_video: 'true'
        // }
    ],

    logLevel: 'info',

    bail: 0,

    baseUrl: 'http://localhost',

    waitforTimeout: 60000,

    connectionRetryTimeout: 90000,

    connectionRetryCount: 0,

    framework: 'mocha',

    reporters: ['spec'],

    mochaOpts: {
        ui: 'bdd',
        timeout: 60000
    }
}