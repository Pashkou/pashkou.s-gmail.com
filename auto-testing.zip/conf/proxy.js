let Proxy = require('browsermob-proxy').Proxy;
let proxy = null;
let proxyApp = null;

const PROXY_PORT = 8888;
const INSTANCE_PORT = 8081;

exports.startProxy = async function startProxy(opts) {
    let { headers } = opts || {};
    await startProxyApp().catch((err) => console.log(err));
    console.log('=================== proxy.started ===================');

    let data = await createProxyInstance().catch((err) => console.log(err));
    console.log('=================== proxy.instance.started ===================', data);

    data = await addHeaders(headers);
    console.log('=================== proxy.headers.added ===================', data);
};

exports.stopProxy = function stopProxy() {
    return new Promise(async (resolve) => {
        await deleteProxyInstance().catch((err) => console.log(err));;
        console.log('=================== proxy.instance.deleted ===================');

        if (proxyApp) {
            //kill tree group
            process.kill(-proxyApp.pid);
            console.log('=================== proxy.stopped ===================');
        }

        resolve();
    })
}

function startProxyApp() {
    return new Promise((resolve, reject) => {
        proxyApp = require('child_process').spawn(
            './browsermob-proxy-2.1.4/bin/browsermob-proxy', ['-port', PROXY_PORT], { detached: true }
        );

        process.on('uncaughtException', (err) => {
            // console.log('process uncaughtException', err);
            //kill app on error
            stopProxy();
        });

        proxyApp.stdout.on('data', (data) => {
            // console.log(`stdout: ${data}`);

            if (data.includes(`FAILED SelectChannelConnector@0.0.0.0:${PROXY_PORT}`)) {
                reject('Failed to start');
            }

            if (data.includes(`Started SelectChannelConnector@0.0.0.0:${PROXY_PORT}`)) {
                resolve();
            }
        });

        proxyApp.stderr.on('data', (data) => {
            // console.log(`stderr: ${data}`);
        });

        proxyApp.on('error', (err) => {
            // console.log('Failed to start proxy app.', err);
            reject(err);
        });

        proxyApp.on('close', (code) => {
            console.log(`proxy process exited with code ${code}`);
        });
    })

}

function createProxyInstance() {
    return new Promise((resolve, reject) => {
        //create proxy instance
        proxy = new Proxy({ port: PROXY_PORT });
        proxy.start(INSTANCE_PORT, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    })
}

function addHeaders(headers) {
    return new Promise((resolve, reject) => {
        proxy.addHeader(8081, headers, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    })
}

function deleteProxyInstance() {
    return new Promise((resolve, reject) => {
        proxy.stop(INSTANCE_PORT, (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    })
}