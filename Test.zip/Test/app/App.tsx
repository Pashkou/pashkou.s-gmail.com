import React from 'react';
import {Admin, Resource, ListGuesser, EditGuesser, CreateGuesser} from 'react-admin';
import axios from 'axios';

import './App.scss';

import authProvider from './authProvider';
import i18nProvider from './i18nProvider';
import jhipsterRestProvider from './dataProvider';

import userReducer from "app/reducers/userReducer";
import siteReducer from "app/reducers/siteReducer";

import { Login, Layout } from './layout';

import customRoutes from './routes';

import QuestionCatalogGroupCat from "app/views/questionCatalogGroupCat/index";
import TextTranslations from "app/views/textTranslations/index";
import People from "app/views/people/index";
import {Dialog, DialogContent, DialogTitle} from "@material-ui/core";
import {Create, SimpleForm, TextInput} from "react-admin";

const App = () => {

    const httpClient = (url, options: any) : Promise<{status: number, headers: Headers, body: string, json: any}> => {
        console.log(options)

        const req = axios({url, ...options, headers: {
                "Content-Type": "application/json"
            }});

        return new Promise((resolve, reject) => {
            req
                .then(response => {
                    const ret : {status: number, headers: Headers, body: string, json: any} = {
                        status: response.status,
                        body: response.data,
                        headers: {...response.headers, has: (x) => response.headers[x] !== null, get: (x) => response.headers[x]},
                        json: response.data
                    }
                resolve(ret);
            })
                .catch(error => {
                    if (typeof error.response === 'undefined') { // to catch CORS errors
                        reject({response: {
                            status: 0
                            }})
                    } else {
                        reject(error);
                    }
            })
        });
    }

    return (
            <Admin
                title=""
                dataProvider={jhipsterRestProvider('http://localhost/api', httpClient)}
                customReducers={{ user: userReducer, site: siteReducer }}
                customRoutes={customRoutes}
                authProvider={authProvider}
                i18nProvider={i18nProvider}
                loginPage={Login}
                layout={Layout}
            >
                <Resource name="question-catalog-group-cats" {...QuestionCatalogGroupCat} />
                <Resource name="text-translations" {...TextTranslations} />
                <Resource name="people" {...People} />
                <Resource name="tax-declarations" />
                <Resource name="tenants" />
                <Resource name="addresses" list={ListGuesser} />
                <Resource name="tokens" list={ListGuesser} />
            </Admin>
    );
};

export default App;
