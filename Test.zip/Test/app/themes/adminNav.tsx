import React from "react";
import PeopleIcon from '@material-ui/icons/People';
import HomeIcon from '@material-ui/icons/Home';
import AttachMoneyIcon from '@material-ui/icons/AttachMoney';
import PublicIcon from '@material-ui/icons/Public';
import HelpIcon from '@material-ui/icons/Help';

export default [
    {
        text: 'pos.menu.sales',
        children: [
            {
                text: "Questionaire Groups",
                icon: <HelpIcon />,
                to: '/question-catalog-group-cats'
            },
            {
                text: "Text Translations",
                icon: <PublicIcon />,
                to: '/text-translations'
            },
            {
                text: "People",
                icon: <PeopleIcon />,
                to: '/people'
            },
            {
                text: "Tokens",
                icon: <AttachMoneyIcon />,
                to: '/tokens'
            },
            {
                text: "Addresses",
                icon: <HomeIcon />,
                to: '/addresses'
            }
        ],
    }
];
