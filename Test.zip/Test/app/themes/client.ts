import {createMuiTheme} from "@material-ui/core";
import { lighten, darken } from '@material-ui/core/styles/colorManipulator';
import adminTheme from "app/themes/admin";


const colorPrimary = '#71B783';
const colorSecondary = '#eee';
const contrastTextPrimary = 'rgba(0, 0, 0, 0.7)';
const contrastTextSecondary = 'rgba(0, 0, 0, 0.7)';



let clientTheme = createMuiTheme({
  palette: {
    primary: {
      light: lighten(colorPrimary, 0.1),
      main: lighten(colorPrimary, 0.05),
      dark: darken(colorPrimary, 0.1),
      contrastText: contrastTextPrimary
    },
    secondary: {
      light: lighten(colorSecondary, 0.5),
      main: lighten(colorSecondary, 0.3),
      dark: lighten(colorSecondary, 0.1),
      contrastText: contrastTextSecondary
    },
    background: {
      default: '#fff'
    }
  },
  typography: {
    h5: {
      fontWeight: 500,
      fontSize: 26,
      letterSpacing: 0.5,
    },
  },
  shape: {
    borderRadius: 8,
  },
  props: {
    MuiTab: {
      disableRipple: false,
    },
  },
  mixins: {
    toolbar: {
      minHeight: 48,
    },
  }
});

clientTheme = {
  ...clientTheme,
  overrides: {
    MuiPaper: {
      rounded: {
        borderRadius: 0
      }
    },
    MuiDrawer: {
      paper: {
        backgroundColor: clientTheme.palette.secondary.dark,
      }
    },
    MuiButton: {
      root: {
        border: `1px solid`
      },
      label: {
        textTransform: 'none',
      },
      contained: {
        boxShadow: 'none',
        '&:active': {
          boxShadow: 'none',
        }
      },
      containedPrimary: {
        color: '#fff',
        borderColor: clientTheme.palette.primary.main
      }
    },
    MuiTabs: {
      root: {
        marginTop: 0,
        marginLeft: 0,
        borderBottom: "1px solid #eee"
      },
      indicator: {
        height: 3,
        borderTopLeftRadius: 0,
        borderTopRightRadius: 0,
        backgroundColor: colorPrimary,
      },
    },
    MuiTab: {
      root: {
        textTransform: 'none',
        marginTop: 0,
        minWidth: 80,
        padding: "10px 20px",
        [clientTheme.breakpoints.up('md')]: {
          padding: "10px 20px",
          minWidth: 80,
        },
        '&:hover': {
          background: "rgba(0, 0, 0, 0.05)"
        }
      },
      selected: {
        background: "rgba(0, 0, 0, 0.05)"
      }
    },
    MuiIconButton: {
      root: {
        padding: clientTheme.spacing(1),
      },
    },
    MuiTooltip: {
      tooltip: {
        borderRadius: 4,
      },
    },
    MuiDivider: {
      root: {
        backgroundColor: clientTheme.palette.secondary.light
      },
    },
    MuiList: {
      root: {
        width: "100%"
      }
    },
    MuiListItemText: {
      primary: {
        fontWeight: clientTheme.typography.fontWeightMedium
      },
    },
    MuiListItemIcon: {
      root: {
        //color: 'inherit',
        color: clientTheme.palette.primary.main,
        marginRight: 0,
        '& svg': {
          fontSize: 20,
        },
      },
    },
    MuiAvatar: {
      root: {
        width: 32,
        height: 32,
      },
    },
    MuiTableCell: {
      root: {
        lineHeight: "32px",
        "& .MuiIcon-root": {
          textAlign: "center",
          color: clientTheme.palette.primary.contrastText,
          background: clientTheme.palette.primary.main,
          borderRadius:100,
          height: 50,
          width:50,
          lineHeight: "30px",
          padding: 10
        }
      }
    }
  },
};

export default clientTheme;
