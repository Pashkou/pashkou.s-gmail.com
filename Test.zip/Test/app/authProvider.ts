import { AuthProvider } from 'ra-core';
import axios from "axios";
import {useStore} from "react-redux";
import {setUser} from "app/reducers/userReducer";
import {loginUrl} from "app/layout/Login";

const authStorageKey = "authenticated";



const authProvider: AuthProvider = {

  login: () => {
    console.log('login called')
    window.location.href = loginUrl;
    return Promise.reject();
  },

  logout: async () => {
    console.log('logout called')
    if (window.localStorage.getItem(authStorageKey) === "true") {
        let response = await axios.post("/api/logout");
        window.location.href = `${response.data.logoutUrl}?redirect_uri=${window.location.origin}/`;
        return Promise.resolve();
    }
    window.localStorage.removeItem(authStorageKey);
    return Promise.reject()
  },

  checkError: (error) => {
    console.log('checkError called', error);

    if (error.response.status === 401 || error.response.status === 403 || error.response.status === 0) {
      window.localStorage.removeItem(authStorageKey);
      return Promise.reject();
    }
    return Promise.resolve();
  },

  checkAuth: async () => {
    console.log('checkAuth called')

    let response = await axios.get("/api/account");
    if (response.status === 200) {
      window.localStorage.setItem(authStorageKey, "true");
      return Promise.resolve();
    }
    window.localStorage.removeItem(authStorageKey);
    return Promise.reject();
  },

  getPermissions: () => {
    return axios.get("/api/account").then((response) => {
      if (response.status === 200) {
        let store = useStore();
        store.dispatch(setUser(response.data))
        //localStorage.setItem('permissions', response.data.authorities);
      }
    });
  }

};

export default authProvider;
