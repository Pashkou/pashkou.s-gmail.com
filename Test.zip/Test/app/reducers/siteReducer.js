// ACTIONS

const SET_SITE = 'SET_SITE';
const SET_TOKEN = 'SET_TOKEN';
const SET_TOKEN_LIST = 'SET_TOKEN_LIST';
const SET_THEME = 'SET_THEME';

export const setSite = (site) => ({
    type: SET_SITE,
    payload: site
});

export const setToken = (token) => ({
    type: SET_TOKEN,
    payload: token
});

export const setTokenList = (tokenList) => ({
    type: SET_TOKEN_LIST,
    payload: tokenList
});

export const setTheme = (theme) => ({
    type: SET_THEME,
    payload: theme
});


// REDUCER

export default (previousState = {theme: "admin", token: null, tokenList: []}, { type, payload }) => {
    if (type === SET_SITE) {
        return payload;
    }

    if (type === SET_TOKEN) {
        return {
            ...previousState,
            token: payload
        };
    }

    if (type === SET_TOKEN_LIST) {
        return {
            ...previousState,
            tokenList: payload
        };
    }

    if (type === SET_THEME) {
        return {
            ...previousState,
            theme: payload
        };
    }


    return previousState;
};
