
import polyglotI18nProvider from 'ra-i18n-polyglot';
import axios from "axios";

import raEnglishMessages from "ra-language-english";
import raFrenchMessages from 'ra-language-french';
import raGermanMessages from 'ra-language-german';

const translationLocaleKey = "translation_locale";
const translationTableKey = "translation_table";
const translationTableDateKey = "translation_table_date";

const initialLocale = localStorage.getItem(translationLocaleKey) || "en";

const getTranslationTableByLocale = (locale: string, messages?: object) => {
    let translations = {};

    if (!messages) return translations;

    switch (locale) {
        case "en":
            Object.assign(translations, raEnglishMessages);
            break;
        case "de":
            Object.assign(translations, raGermanMessages);
            break;
        case "fr":
            Object.assign(translations, raFrenchMessages);
            break;
    }

    return Object.assign(translations, messages[locale]);
}


export default polyglotI18nProvider(locale => {
    console.log("i18nProvider called");

    localStorage.setItem(translationLocaleKey, locale);

    const translationTable = localStorage.getItem(translationTableKey);
    const translationTableDate = localStorage.getItem(translationTableDateKey);

    if (translationTable === null || (new Date().getTime() - new Date(translationTableDate).getTime()) > (1000 * 60 * 60)) {
        axios("/api/texts", {
            headers: []
        }).then(result => {
            localStorage.setItem(translationTableKey, JSON.stringify(result.data));
            localStorage.setItem(translationTableDateKey, new Date().getTime() + "");

            return getTranslationTableByLocale(locale, result.data);
        });

        return getTranslationTableByLocale(locale);
    } else {
        return getTranslationTableByLocale(locale, JSON.parse(translationTable));
    }
}, initialLocale, {
    allowMissing: true
    }
);
