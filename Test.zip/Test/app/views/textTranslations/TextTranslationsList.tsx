import React from 'react';
import {List, Datagrid, TextField} from "react-admin";

export const TextTranslationList = props => (
    <List {...props}>
        <Datagrid rowClick="edit">
            <TextField source="id" />
            <TextField source="key" />
            <TextField source="de" />
            <TextField source="en" />
            <TextField source="fr" />
        </Datagrid>
    </List>
);

export default TextTranslationList;
