import React, {cloneElement} from 'react';
import {
    Datagrid,
    TextField,
    ReferenceField,
    DateField,
    NumberField,
    TopToolbar,
    sanitizeListRestProps,
    CreateButton,
    ExportButton, Resource, Admin
} from "react-admin";
import TabbedList from '../../components/TabbedList';
import Icon from "@material-ui/core/Icon";
import {FullNameField, IconField, TwoLineField} from "app/components/CustomFields";

export const PeopleList = props => {

    const tabs = [
        {
            label: "Required Action",
            filter: {investorStatus: "REQUESTED,DUE_DILIGENCE"}
        },
        {
            label: "All",
            filter: {}
        },
        {
            label: "Requested",
            filter: {investorStatus: "REQUESTED"}
        },
        {
            label: "DD",
            filter: {investorStatus: "DUE_DILIGENCE"}
        },
        {
            label: "Approved",
            filter: {investorStatus: "APPROVED"}
        },
        {
            label: "Rejected",
            filter: {investorStatus: "REJECTED"}
        }
    ]

    const icons = {
        "AUTOIDENT": <Icon className="far fa-id-card"/>,
        "VIDEOIDENT": <Icon className="fa fa-video"/>,
        "ON_PREMIS": <Icon className="fa fa-user"/>
    }

    const ListActions = (props) => {
        const {
            currentSort,
            className,
            resource,
            filters,
            displayedFilters,
            exporter, // you can hide ExportButton if exporter = (null || false)
            filterValues,
            permanentFilter,
            hasCreate, // you can hide CreateButton if hasCreate = false
            basePath,
            selectedIds,
            onUnselectItems,
            showFilter,
            maxResults,
            total,
            ...rest
        } = props;
        return(
            <TopToolbar className={className} {...sanitizeListRestProps(rest)}>
                {filters && cloneElement(filters, {
                    resource,
                    showFilter,
                    displayedFilters,
                    filterValues,
                    context: 'button',
                })}
                <CreateButton basePath={basePath}/>
                <ExportButton
                    disabled={total === 0}
                    resource={resource}
                    sort={currentSort}
                    filter={{...filterValues, ...permanentFilter}}
                    exporter={exporter}
                    maxResults={maxResults}
                />
            </TopToolbar>
        );
    }

    return (
        <TabbedList {...props} tabs={tabs} actions={<ListActions />}>
            <Datagrid rowClick="edit">
                <TextField source="id"/>
                <FullNameField source="lastName" label="Full name"/>
                <TwoLineField source="category" label="Type / Category" line1="type" line2="category" />
                <DateField source="dateOfBirth"/>
                <ReferenceField source="taxId" reference="taxes"><TextField source="id"/></ReferenceField>
                <NumberField source="investmentLimit"/>
                <TextField source="escrowAccountNumber"/>
                {/*<IconField source="identificationMethod" icons={icons}/>*/}
                <NumberField source="completion"/>
                <TextField source="investorStatus"/>
                <ReferenceField source="tenantId" reference="tenants"><TextField source="id"/></ReferenceField>
            </Datagrid>
        </TabbedList>
    );
}

export default PeopleList;
