
import React, {useEffect, useState} from 'react';
import {
    Edit,
    SimpleForm,
    TextInput,
    ReferenceInput,
    SelectInput,
    NumberInput,
    ReferenceArrayField,
    Datagrid,
    TextField,
    EditButton,
    CreateButton,
    Create,
    SaveButton,
    TabbedForm,
    FormTab
} from "react-admin";
import {DatePickerInput} from "app/components/CustomInputs";
import {Button, Dialog, DialogContent, DialogTitle, Toolbar} from "@material-ui/core";
import AddIcon from '@material-ui/icons/Add';
import SaveIcon from '@material-ui/icons/Save';
import CloseIcon from '@material-ui/icons/Close';

const ModalToolbar = props => {
    const {onClose, handleSubmit} = props;

    const handleClickSave = () => {
        handleSubmit();
        onClose();
    }

    const handleClickCancel = () => {
        onClose();
    }

    return (
        <Toolbar>
            <Button color="primary" startIcon={<SaveIcon/>} variant="contained" onClick={handleClickSave}>Save</Button> &nbsp;
            <Button color="primary" startIcon={<CloseIcon/>} variant="contained" onClick={handleClickCancel}>Cancel</Button>
        </Toolbar>
    )
};

const ModalCreate = (props) => {
    const {open, onClose} = props;

    const handleClose = () => {
        onClose();
    }

    console.log(props)
    return (
        <Dialog fullWidth open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
            <DialogTitle id="form-dialog-title">Add new Address</DialogTitle>
            <DialogContent dividers>
                <Create {...props} resource="addresses" record={null}>
                    <SimpleForm toolbar={<ModalToolbar onClose={onClose}/>} initialValues={{userId: props.id}}>
                        <TextInput source="streetName"/>
                        <TextInput source="streetNumber"/>
                        <TextInput source="zipCode"/>
                        <TextInput source="city"/>
                        <TextInput source="country"/>
                        <TextInput source="additionalAddressLine"/>
                        <TextInput source="addressType"/>
                        <TextInput source="tenant"/>
                    </SimpleForm>
                </Create>
            </DialogContent>
        </Dialog>
    )
}

const PeopleEdit = (props) => {
    const [createModalOpen, setCreateModalOpen] = useState(false);

    return (
        <React.Fragment>
            <Edit {...props}>
                <TabbedForm>
                    <FormTab label="Base Data">
                        <TextInput source="id"/>
                        <TextInput source="type"/>
                        <TextInput source="category"/>
                        <TextInput source="firstName"/>
                        <TextInput source="lastName"/>
                        <ReferenceInput source="taxId" reference="tax-declarations"><SelectInput
                            optionText="id"/></ReferenceInput>
                        <DatePickerInput source="dateOfBirth"/>
                    </FormTab>
                    <FormTab label="Due Diligence">
                        <NumberInput source="investmentLimit"/>
                        <TextInput source="escrowAccountNumber"/>
                        <TextInput source="identificationMethod"/>
                        <NumberInput source="completion"/>
                    </FormTab>
                    <FormTab label="Addresses">
                    <TextInput source="investorStatus"/>
                    <ReferenceInput source="tenantId" reference="tenants"><SelectInput optionText="id"/></ReferenceInput>
                    <ReferenceArrayField label="Addresses" reference="addresses" source="addresses">
                        <Datagrid>
                            <TextField source="id"/>
                            <TextField source="streetName"/>
                            <TextField source="streetNumber"/>
                            <TextField source="zipCode"/>
                            <TextField source="city"/>
                            <TextField source="country"/>
                            <TextField source="additionalAddressLine"/>
                            <TextField source="addressType"/>
                            <TextField source="tenant"/>
                            <EditButton/>
                        </Datagrid>
                    </ReferenceArrayField>
                    <Button color="primary"
                            startIcon={<AddIcon />}
                            onClick={() => {
                                setCreateModalOpen(true);
                            }}>
                        Add new Address
                    </Button>
                    </FormTab>
                </TabbedForm>
            </Edit>
            <ModalCreate open={createModalOpen} onClose={() => setCreateModalOpen(false)} {...props}/>
        </React.Fragment>
    )
};

export default PeopleEdit;
