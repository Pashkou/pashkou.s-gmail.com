
import React from 'react';
import {Create, SimpleForm, TextInput, ReferenceInput, SelectInput, DateInput, NumberInput} from "react-admin";

const PeopleCreate = props => (
    <Create {...props}>
        <SimpleForm>
            <TextInput source="type" />
            <TextInput source="category" />
            <TextInput source="firstName" />
            <TextInput source="lastName" />
            <ReferenceInput source="taxId" reference="tax-declarations"><SelectInput optionText="id" /></ReferenceInput>
            <DateInput source="dateOfBirth" />
            <NumberInput source="investmentLimit" />
            <TextInput source="escrowAccountNumber" />
            <TextInput source="identificationMethod" />
            <NumberInput source="completion" />
            <TextInput source="investorStatus" />
            <ReferenceInput source="tenantId" reference="tenants"><SelectInput optionText="id" /></ReferenceInput>
        </SimpleForm>
    </Create>
);

export default PeopleCreate;
