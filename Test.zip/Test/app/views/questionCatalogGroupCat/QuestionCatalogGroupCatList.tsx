import React, {Fragment} from 'react';
import {Datagrid, TextField, ReferenceField} from "react-admin";
import TabbedList from '../../components/TabbedList';

const QuestionCatalogGroupCatList = props => {
    const tabs = [
        {
            label: "All",
            filter: {}
        },
        {
            label: "ID=2",
            filter: {id: 2}
        },
        {
            label: "ID=3",
            filter: {id: 3}
        }
    ]

    return (
        <TabbedList {...props} tabs={tabs}>
            <Datagrid rowClick="edit" >
                <TextField source="id" />
                <ReferenceField source="helpId" reference="text-translations"><TextField source="key" /></ReferenceField>
                <ReferenceField source="helpTextId" reference="text-translations"><TextField source="key" /></ReferenceField>
            </Datagrid>
        </TabbedList>
    );
}

export default QuestionCatalogGroupCatList;
