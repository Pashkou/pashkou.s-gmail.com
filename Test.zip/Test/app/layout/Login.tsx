const port = window.location.port ? `:${window.location.port}` : '';

export const loginUrl = `http://${window.location.hostname}${port}${window.location.pathname}oauth2/authorization/oidc?redirect_uri=http://${window.location.hostname}${port}`;

export default () => {
    window.location.href = loginUrl;
}
