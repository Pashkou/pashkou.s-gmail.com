import React, {useEffect} from 'react';
import PropTypes from 'prop-types';
import {useDataProvider, useTranslate} from "react-admin";
import {createMuiTheme, createStyles, makeStyles, ThemeProvider, withStyles} from '@material-ui/core/styles';
import CssBaseline from '@material-ui/core/CssBaseline';
import Hidden from '@material-ui/core/Hidden';
import Typography from '@material-ui/core/Typography';
import Link from '@material-ui/core/Link';
import {Notification} from "react-admin";
import Navigator from "./Navigator";
import Header from "./Header";
import {RootStateOrAny, useDispatch, useSelector, useStore} from "react-redux";
import axios from "axios";
import {setUser} from "app/reducers/userReducer";
import { Store } from 'redux';
import {Paper, Grid} from "@material-ui/core";
import {setToken, setTokenList} from "app/reducers/siteReducer";
import adminTheme from "app/themes/admin";
import clientTheme from "app/themes/client";

function Copyright(): any {
    return (
        <Typography variant="body2" color="textSecondary" align="center">
            {'Copyright © '}
            <Link color="inherit" href="https://material-ui.com/">
                Your Website
            </Link>{' '}
            {new Date().getFullYear()}
            {'.'}
        </Typography>
    );
}

const drawerWidth = 256;
const useStyles = makeStyles(theme => ({
    root: {
        display: 'flex',
        minHeight: '100vh',
        overflowX: 'hidden'
    },
    drawer: {
        [theme.breakpoints.up('sm')]: {
            width: drawerWidth,
            flexShrink: 0,
        },
    },
    app: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        overflowX: 'hidden'
    },
    title: {
        flex: 1,
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        marginBottom: 20
    },
    main: {
        flex: 1,
        padding: theme.spacing(6, 4),
        background: theme.palette.background.default,
        //overflow:'auto'
    },
    footer: {
        padding: theme.spacing(2),
        background: theme.palette.background.default,
    },
}))


const LayoutWithTheme = (props) => {
    const [mobileOpen, setMobileOpen] = React.useState(false);
    const dataProvider = useDataProvider();
    const siteState = useSelector((state: any) => state.site);
    const userState = useSelector((state: any) => state.user);
    const dispatch = useDispatch();

    if (userState === null) {
        axios.get("/api/account").then((response) => {
            if (response.status === 200) {
                dispatch(setUser(response.data));
            }
        });
    }
    useEffect(() => {
        dataProvider.getList('tokens', {pagination: {}, sort: {}, filter: {}})
            .then(({ data }) => {
                dispatch(setTokenList(data))
                if (!siteState.token) {
                    dispatch(setToken(data[0]))
                }
            })
            .catch(error => {
                console.log(error)
            })
    }, []);

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen);
    };


    const classes = useStyles();

    const translate = useTranslate();
    return (
        <React.Fragment>
        <div className={classes.root}>
            <CssBaseline />
            <nav className={classes.drawer}>
                <Hidden smUp implementation="js">

                    <Navigator
                        PaperProps={{ style: { width: drawerWidth } }}
                        variant="temporary"
                        open={mobileOpen}
                        onClose={handleDrawerToggle}
                    />

                </Hidden>
                <Hidden xsDown implementation="css">
                    <Navigator PaperProps={{ style: { width: drawerWidth } }} />
                </Hidden>
            </nav>
            <div className={classes.app}>

                <Header onDrawerToggle={handleDrawerToggle} />
                <main className={classes.main}>

                    {siteState.token &&
                    <Paper>
                        <Grid container spacing={3}>
                            <Grid item>
                                <Grid container>
                                    <Grid item>
                                        {translate("test")}
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                        {siteState.token.name}
                    </Paper>
                    }

                    <Typography
                        variant="h4"
                        color="inherit"
                        className={classes.title}
                        id="react-admin-title"
                    />

                    {props.children}
                </main>
                <footer className={classes.footer}>
                    <Copyright />
                </footer>
            </div>
        </div>
        <Notification />
        </React.Fragment>
    )
}

const Layout = (props: any) => {
    const siteState = useSelector((state: any) => state.site);

    let theme;

    if (siteState.theme === "admin") {
        theme = adminTheme;
    } else if (siteState.theme === "client") {
        theme = clientTheme;
    }

    return (
        <ThemeProvider theme={theme}>
            <LayoutWithTheme {...props} />
        </ThemeProvider>
    );
}

export default Layout;
