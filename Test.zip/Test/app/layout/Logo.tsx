import React from 'react';
import logo from '../../content/images/logo.png';
import logoClient from '../../content/images/logo-seba.png';
import {createStyles, Theme, withStyles} from "@material-ui/core";
import {useSelector} from "react-redux";

const styles = (theme: Theme) =>
    createStyles({
        logoAdmin: {
            width: "90%",
            marginLeft: "5%",
            marginRight: "5%"
        },
        logoClient: {
            width: "82%",
            marginLeft: "9%",
            marginRight: "9%",
            marginTop: "10px",
            marginBottom: "10px"
        }
    })

const Logo = (props: any) => {
    const {classes} = props;
    const siteState = useSelector((state: any) => state.site);

    if (siteState.theme === "admin") {
        return (
            <img src={logo} className={classes.logoAdmin}/>
        )
    } else if (siteState.theme === "client") {
        return (
            <img src={logoClient} className={classes.logoClient}/>
        )
    }
}

export default withStyles(styles)(Logo);
